// src/components/Div3.jsx

import React from 'react';
import './div3.css';

const Div3 = () => {
  return (
    <div className="group-3">
  <div className="design-3 group">
    <div className="col-3">
      <div className="text-2">
        <p className="pretitle-3">SUPPORT OUR FARMERS</p>
        <p className="title-3">
          Shop Local:
          <br />
          Our Cause
        </p>
        <p className="paragraph-2">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris
        </p>
        <p className="button-3">OUR PROMISE</p>
      </div>
      <div className="button-4" />
    </div>
    <div className="wrapper-6">
      <div className="rectangle-5" />
      <img className="rectangle-6" src="images/rectangle_6.png" alt="" />
    </div>
  </div>
</div>

  );
};

export default Div3;
