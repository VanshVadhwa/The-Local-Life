import React from 'react';
import './div1.css';

const Div1 = () => {
  return (
    <div id='home' className="group-1">
      <div className="background-holder">
        <div className="button" />
      </div>
      <img
        className="rectangle"
        src="images/rectangle_10.png"
        alt=""
      />
      <div className="text">
        <p className="pretitle">SUPPORT LOCAL:</p>
        <p className="title">
          From our farms
          <br />
          to your kitchen.
        </p>
        <p className="paragraph">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
          veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.
        </p>
        <p className="button-2">SHOP NOW</p>
      </div>
    </div>
  );
}

export default Div1;
