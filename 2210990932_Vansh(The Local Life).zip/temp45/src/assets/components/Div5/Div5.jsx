// src/components/Div5.jsx

import React from 'react';
import './div5.css';

const Div5 = () => {
  return (
    <div id='Shop' className="group-5 group">
  <div className="col">
    <div className="text-4">
      <p className="title-5">
        Fresh Daily
        <br />
        Products
      </p>
      <p className="paragraph-4">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
        veniam, quis nostrud exercitation ullamco laboris
      </p>
      <p className="button-7">SHOP TODAY</p>
    </div>
    <div className="button-8" />
  </div>
  <img className="image-3" src="images/image.jpg" alt="" />
</div>

  );
};

export default Div5;
