// src/components/Div7.jsx

import React from 'react';
import './div7.css';

const Div7 = () => {
  return (
    <div id='About' className="group-7">
  <img className="rectangle-7" src="images/rectangle.png" alt="" />
  <img className="rectangle-8" src="images/rectangle_2.png" alt="" />
  <img className="rectangle-9" src="images/rectangle_3.png" alt="" />
  <img className="rectangle-10" src="images/rectangle_4.png" alt="" />
  <div className="button-9">SEE MORE</div>
  <div className="text-14">
    <p className="title-7">Our Local Farms</p>
    <div className="row-6 match-height group">
      <div className="col-12">
        <p className="heading-4">SAN ISIDRO, HAMPTON, COUNTRY</p>
        <p className="paragraph-5">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
        </p>
      </div>
      <div className="col-13">
        <p className="heading-5">CREEKSIDE, LOUVE, COUNTRY</p>
        <p className="paragraph-6">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
        </p>
      </div>
    </div>
    <div className="row-7 match-height group">
      <div className="col-14">
        <p className="heading-6">SEBAST, FRAUGH, COUNTRY</p>
        <p className="paragraph-7">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
        </p>
      </div>
      <div className="col-15">
        <p className="heading-7">ZEPHYR, HAMPTON, COUNTRY</p>
        <p className="paragraph-8">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
        </p>
      </div>
    </div>
    <a href="">
      <p className="button-10">SEE MORE</p>
    </a>
  </div>
</div>

  );
};

export default Div7;
