import React from 'react';
import './Navbar.css';

const Navbar = () => {
  return (
    <div className="background">
    <div className="toolbar">
    <div className="l-constrained-3 group">
      <img
        className="place-your-logo-here-double-click-to-edit"
        src="images/place_your_logo_here_doub.jpg"
        alt=""
        width={236}
        height={40}
      />
      <nav className="nav">
        <ul className="nav-list group">
          <li>
            <p className="nav-item-1">
              <a href="#home">Home</a>
            </p>
          </li>
          <li>
            <p className="nav-item-1-2">
              <a href="#About">About</a>
            </p>
          </li>
          <li>
            <p className="nav-item-1-3">
              <a href="#Shop">Shop</a>
            </p>
          </li>
          <li>
            <p className="nav-item-1-4">
              <a href="#contact">Contact Us</a>
            </p>
          </li>
        </ul>
      </nav>
      <div className="design group">
        <a href="">
          <img
            className="search-icon"
            src="images/search_icon.png"
            alt=""
            width={23}
            height={23}
          />
        </a>
        <a href="">
          <img
            className="cart-icon"
            src="images/cart_icon.png"
            alt=""
            width={29}
            height={29}
          />
        </a>
      </div>
    </div>
  </div>
</div>

  );
}

export default Navbar;
