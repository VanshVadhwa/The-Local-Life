// src/components/Div4.jsx

import React from 'react';
import './div4.css';

const Div4 = () => {
  return (
    <div className="l-constrained">
  <div className="group-4 group">
    <img className="image-2" src="images/image_2.jpg" alt="" />
    <div className="col-2">
      <div className="text-3">
        <p className="title-4">
          Newly
          <br />
          Harvest
        </p>
        <p className="paragraph-3">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco
        </p>
        <p className="button-5">OUR PRODUCTS</p>
      </div>
      <div className="button-6" />
    </div>
  </div>
</div>

  );
};

export default Div4;
