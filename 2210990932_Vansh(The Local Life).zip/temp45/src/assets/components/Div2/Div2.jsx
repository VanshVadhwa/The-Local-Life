// src/components/Div2.jsx

import React from 'react';
import './div2.css';

const Div2 = () => {
  return (
    <div className="group-2">
  <div className="l-constrained-2">
    <p className="pretitle-2">READY FOR</p>
    <p className="title-2">WHAT’S NEW?</p>
    <div className="image no-space-between-inline-blocks">
      <img className="rectangle-2" src="images/rectangle_7.png" alt="" />
      <img className="rectangle-3" src="images/rectangle_9.png" alt="" />
      <img className="rectangle-4" src="images/rectangle_8.png" alt="" />
    </div>
    <div className="row-4 group">
      <p className="heading">
        GREEN VEGETABLES PACK
        <br />
        $12.99
      </p>
      <p className="heading-2">
        FRUIT CART PACKS
        <br />
        $12.99
      </p>
      <p className="heading-3">
        LEMONS &amp; ORANGE PACKS
        <br />
        $12.99
      </p>
    </div>
    <div className="design-2 no-space-between-inline-blocks">
      <div className="ellipse" />
      <div className="ellipse-2" />
      <div className="ellipse-3" />
      <div className="ellipse-4" />
    </div>
  </div>
</div>

  );
};

export default Div2;
