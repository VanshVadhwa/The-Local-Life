// src/components/Div6.jsx

import React from 'react';
import './div6.css';

const Div6 = () => {
  return (
    <div className="group-6">
  <div className="text-5">
    <p className="title-6">Testimonials</p>
    <p className="pretitle-4">WHY CUSTOMERS LOVE US</p>
    <div className="row-8 match-height group">
      <div className="col-18">
        <img
          className="place-your-image-here-double-click-to-edit"
          src="images/place_your_image_here_dou_7.png"
          alt=""
          width={139}
          height={139}
        />
        <p className="text-6">CLIENT NAME</p>
        <p className="text-7">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum
          suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan
          lacus vel facilisis.
        </p>
        <img
          className="place-your-image-here-double-click-to-edit-2"
          src="images/place_your_image_here_dou_8.png"
          alt=""
          width={139}
          height={139}
        />
      </div>
      <div className="col-19">
        <img
          className="place-your-image-here-double-click-to-edit-3"
          src="images/place_your_image_here_dou_5.png"
          alt=""
          width={139}
          height={139}
        />
        <p className="text-8">CLIENT NAME</p>
        <p className="text-9">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum
          suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan
          lacus vel facilisis.
        </p>
        <img
          className="place-your-image-here-double-click-to-edit-4"
          src="images/place_your_image_here_dou_6.png"
          alt=""
          width={139}
          height={139}
        />
      </div>
    </div>
    <div className="row-5 match-height group">
      <div className="col-10">
        <p className="text-10">CLIENT NAME</p>
        <p className="text-11">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum
          suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan
          lacus vel facilisis.
        </p>
      </div>
      <div className="col-11">
        <p className="text-12">CLIENT NAME</p>
        <p className="text-13">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum
          suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan
          lacus vel facilisis.
        </p>
      </div>
    </div>
  </div>
</div>

  );
};

export default Div6;
