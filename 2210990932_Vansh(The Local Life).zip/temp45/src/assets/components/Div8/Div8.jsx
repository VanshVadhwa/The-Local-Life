// src/components/Div8.jsx

import React from 'react';
import './div8.css';

const Div8 = () => {
  return (
    <div id='contact' className="group-8">
  <div className="text-15 group">
    <div className="col-17">
      <div className="row-9 group">
        <div className="col-20">
          <p className="title-8">
            LOCAL
            <br />
            LIFE
          </p>
          <div className="social-media-icons group">
            <img
              className="vector-smart-object-double-click-to-edit"
              src="images/vector_smart_object_doubl.png"
              alt=""
              width={30}
              height={30}
            />
            <img
              className="vector-smart-object-double-click-to-edit-2"
              src="images/vector_smart_object_doubl_2.png"
              alt=""
              width={29}
              height={29}
            />
            <img
              className="vector-smart-object-double-click-to-edit-3"
              src="images/vector_smart_object_doubl_3.png"
              alt=""
              width={33}
              height={27}
            />
          </div>
        </div>
        <div className="col-21 group">
          <p className="heading-8">OUR SERVICES</p>
          <p className="subheading">
            What’s New
            <br />
            How to Order
            <br />
            Payment Method
            <br />
            Order Status
            <br />
            Subscription
          </p>
        </div>
      </div>
      <p className="copyright">
        Copyright 2021 The Local Life Co. All Rights Reserved.
      </p>
    </div>
    <div className="our-team">
      <p className="heading-9">OUR TEAM</p>
      <p className="subheading-2">
        Our Local Farms
        <br />
        Craftsmanship
        <br />
        Our Sources
        <br />
        Sustainability
      </p>
    </div>
    <div className="legal">
      <p className="heading-10">LEGAL</p>
      <p className="subheading-3">
        Privacy Policy
        <br />
        Our Promise
        <br />
        More Information
      </p>
    </div>
  </div>
</div>


  );
};

export default Div8
