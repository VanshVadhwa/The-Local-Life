import React from 'react';
import './App.css';

import Navbar from './assets/components/Navbar/Navbar'; 
import Div1 from './assets/components/Div1/Div1'; 
import Div2 from './assets/components/Div2/Div2';
import Div3 from './assets/components/Div3/Div3';
import Div4 from './assets/components/Div4/Div4';
import Div5 from './assets/components/Div5/Div5';
import Div6 from './assets/components/Div6/Div6';
import Div7 from './assets/components/Div7/Div7';
import Div8 from './assets/components/Div8/Div8';

import '../src/components/responsive.css'

function App() {
  return (
    <div className="App">
      <Navbar />
      <Div1 />
      <Div2 />
      <Div3 />
      <Div4 />
      <Div5 />
      <Div6 />
      <Div7 />
     <Div8 />   
    </div>
  );
}

export default App;
